package foodshortage;

public interface Buyer {
    public void buyFood();
    public int getFood();

}
