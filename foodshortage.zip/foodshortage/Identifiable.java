package foodshortage;

public interface Identifiable {
    public String getId();

}
