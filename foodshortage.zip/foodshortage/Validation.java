package foodshortage;

public class Validation {

}
