package foodshortage;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int numberOfPeople = Integer.parseInt(scanner.nextLine());
        HashMap<String,Buyer> people = new HashMap<>();

        for (int i = 0; i < numberOfPeople ; i++) {
           String[] tokens = scanner.nextLine().split("\\s+");
           String name = tokens[0];
           int age = Integer.parseInt(tokens[1]);

           if(Character.isDigit(tokens[2].charAt(0))){
               String id = tokens[2];
               String birthDate = tokens[3];
               Citizen citizen = new Citizen(name,age,id,birthDate);
               people.putIfAbsent(name,citizen);
           } else {
               String group = tokens[2];
               Rebel rebel = new Rebel(name,age,group);
               people.putIfAbsent(name,rebel);
           }
        }

        String input = scanner.nextLine();
        while (!input.equals("End")){
            String name = input;
            if(people.containsKey(name)){
                people.get(name).buyFood();
            }

            input = scanner.nextLine();
        }
        int total=0;
        for (Buyer buyer : people.values()) {
            total+=buyer.getFood();
        }
        System.out.println(total);
    }
}
