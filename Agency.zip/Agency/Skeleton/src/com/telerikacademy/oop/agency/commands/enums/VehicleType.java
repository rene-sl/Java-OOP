package com.telerikacademy.oop.agency.commands.enums;

import com.telerikacademy.oop.agency.models.vehicles.contracts.Bus;

public enum VehicleType {
    TRAIN, AIRPLANE , BUS;

    @Override
    public String toString(){
        switch (this){
            case BUS:
                return "Bus";
            case TRAIN:
                return "Train";
            case AIRPLANE:
                return "Airplane";
            default: return "Unknown vehicle";

        }
    }
}
