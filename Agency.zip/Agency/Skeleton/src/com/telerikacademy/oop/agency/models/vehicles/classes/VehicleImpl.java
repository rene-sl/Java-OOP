package com.telerikacademy.oop.agency.models.vehicles.classes;

import com.telerikacademy.oop.agency.commands.enums.VehicleType;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Vehicle;

public abstract class VehicleImpl implements Vehicle {
    private int passengerCapacity;
    private VehicleType type;
    private double pricePerKilometer;

    public VehicleImpl(int passengerCapacity, VehicleType type, double pricePerKilometer) {
        setPassengerCapacity(passengerCapacity);
        setType(type);
        setPricePerKilometer(pricePerKilometer);
    }

     abstract void validateCapacity(int passengerCapacity);
     abstract void validatePricePerKilometer(double pricePerKilometer);


    private  void setPassengerCapacity(int passengerCapacity) {
        validateCapacity(passengerCapacity);
        this.passengerCapacity = passengerCapacity;
    }
    private void setType(VehicleType type) {
        this.type = type;
    }

    private void setPricePerKilometer(double pricePerKilometer) {
        validatePricePerKilometer(pricePerKilometer);
        this.pricePerKilometer = pricePerKilometer;
    }

    @Override
    public int getPassengerCapacity() {
        return this.passengerCapacity;
    }

    @Override
    public double getPricePerKilometer() {
        return this.pricePerKilometer;
    }

    @Override
    public VehicleType getType() {
        return this.type;
    }

    @Override
    public String toString(){
        return String.format("Passenger capacity: %d%n Price per kilometer: %.2f%nVehicle type: %s%n",
                getPassengerCapacity(), getPricePerKilometer(), getType());
    }
}
