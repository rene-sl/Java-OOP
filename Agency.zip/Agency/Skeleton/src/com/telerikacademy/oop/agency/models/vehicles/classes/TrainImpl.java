package com.telerikacademy.oop.agency.models.vehicles.classes;

import com.telerikacademy.oop.agency.commands.enums.VehicleType;
import com.telerikacademy.oop.agency.models.ValidationMessages;
import com.telerikacademy.oop.agency.models.Validator;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Train;

public class TrainImpl extends VehicleImpl implements Train {
    private static final int PASSENGER_CAPACITY_MIN = 30;
    private static final int PASSENGER_CAPACITY_MAX = 150;
    private static final int CARTS_MAX = 15;
    private static final int CARTS_MIN = 1;
    private static final double PRICE_PER_KILOMETER_MIN = 0.1;
    private static final double PRICE_PER_KILOMETER_MAX = 2.5;

    private int carts;

    public TrainImpl(int passengerCapacity, VehicleType type, double pricePerKilometer) {
        super(passengerCapacity, type, pricePerKilometer);
        setCarts(carts);
    }

    private void setCarts(int carts) {
        if( carts < CARTS_MIN || CARTS_MAX < carts ){
            throw new IllegalArgumentException(ValidationMessages.TRAIN_CARTS_INCORRECT);
        }
        this.carts = carts;

    }

    @Override
    void validateCapacity(int passengerCapacity) {
        Validator.checkCapacity(passengerCapacity,
                PASSENGER_CAPACITY_MAX, PASSENGER_CAPACITY_MIN);
    }

    @Override
    void validatePricePerKilometer(double pricePerKilometer) {

    }

    @Override
    public int getCarts() {
        return this.carts;
    }

    @Override
    public String toString(){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Train ----%n");
        stringBuilder.append(super.toString());
        stringBuilder.append(String.format("Carts amount: %d",getCarts()));

        return stringBuilder.toString().trim();
    }
}
