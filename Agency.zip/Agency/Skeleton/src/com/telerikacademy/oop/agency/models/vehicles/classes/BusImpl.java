package com.telerikacademy.oop.agency.models.vehicles.classes;

import com.telerikacademy.oop.agency.commands.enums.VehicleType;
import com.telerikacademy.oop.agency.models.Validator;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Bus;

public class BusImpl extends VehicleImpl implements Bus {
    private static final int PASSENGER_CAPACITY_MIN = 10;
    private static final int PASSENGER_CAPACITY_MAX = 50;
    private static final double PRICE_PER_KILOMETER_MIN = 0.1;
    private static final double PRICE_PER_KILOMETER_MAX = 2.5;

    public BusImpl(int passengerCapacity, VehicleType type, double pricePerKilometer) {
        super(passengerCapacity, type, pricePerKilometer);
    }

    @Override
    void validateCapacity(int passengerCapacity) {
        Validator.checkCapacity(passengerCapacity,
                PASSENGER_CAPACITY_MAX, PASSENGER_CAPACITY_MIN);
    }

    @Override
    void validatePricePerKilometer(double pricePerKilometer) {
        Validator.checkPrice(pricePerKilometer, PRICE_PER_KILOMETER_MAX, PRICE_PER_KILOMETER_MIN);
    }

    @Override
    public String toString(){
        return String.format("Bus ----%n" +
                "Passenger capacity: %d%n" +
                "Price per kilometer: %.2f%n" +
                "Vehicle type: %s",
                super.getPassengerCapacity(), super.getPricePerKilometer(),
                super.getType());
    }
}
