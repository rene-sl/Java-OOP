package com.telerikacademy.oop.agency.core.contracts;

import com.telerikacademy.oop.agency.models.contracts.Journey;
import com.telerikacademy.oop.agency.models.contracts.Ticket;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Airplane;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Bus;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Train;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Vehicle;

public interface AgencyFactory {
    
    Bus createBus(int passengerCapacity, double pricePerKilometer);
    
    Train createTrain(int passengerCapacity, double pricePerKilometer, int carts);
    
    Airplane createAirplane(int passengerCapacity, double pricePerKilometer, boolean hasFreeFood);
    
    Journey createJourney(String startingLocation, String destination, int distance, Vehicle vehicle);
    
    Ticket createTicket(Journey journey, double administrativeCosts);
    
}