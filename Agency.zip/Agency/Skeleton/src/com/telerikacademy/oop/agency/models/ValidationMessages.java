package com.telerikacademy.oop.agency.models;

public class ValidationMessages {
    public static final String PRICE_INVALID = "Invalid price.";
    public static final String CAPACITY_INVALID = "A %s cannot" +
            " have less than %d passengers or more than %d passengers.";
    public static final String TRAIN_CARTS_INCORRECT = "A train cannot have " +
            "less than 1 cart or more than 15 carts.";
}
