package com.telerikacademy.oop.agency.models.contracts;

import com.telerikacademy.oop.agency.models.vehicles.contracts.Vehicle;

public class JourneyIml implements Journey {


    @Override
    public String getDestination() {
        return null;
    }

    @Override
    public int getDistance() {
        return 0;
    }

    @Override
    public String getStartLocation() {
        return null;
    }

    @Override
    public Vehicle getVehicle() {
        return null;
    }

    @Override
    public double calculateTravelCosts() {
        return 0;
    }
}
