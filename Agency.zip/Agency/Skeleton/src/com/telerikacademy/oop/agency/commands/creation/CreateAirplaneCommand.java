package com.telerikacademy.oop.agency.commands.creation;

import com.telerikacademy.oop.agency.commands.contracts.Command;

import java.util.List;

public class CreateAirplaneCommand implements Command {
    @Override
    public String execute(List<String> parameters) {
        return null;
    }

}