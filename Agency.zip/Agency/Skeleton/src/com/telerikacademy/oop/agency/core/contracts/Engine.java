package com.telerikacademy.oop.agency.core.contracts;

public interface Engine {
    
    void start();
    
}