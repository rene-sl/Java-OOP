package com.telerikacademy.oop.agency.models.contracts;

public class TicketImpl implements Ticket {
    @Override
    public double getAdministrativeCosts() {
        return 0;
    }

    @Override
    public Journey getJourney() {
        return null;
    }

    @Override
    public double calculatePrice() {
        return 0;
    }
}
