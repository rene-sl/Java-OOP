package com.telerikacademy.oop.agency.models.vehicles.classes;

import com.telerikacademy.oop.agency.commands.enums.VehicleType;
import com.telerikacademy.oop.agency.models.vehicles.contracts.Airplane;

public class AirplaneImpl extends VehicleImpl implements Airplane {

    private boolean hasFreeFood;

    public AirplaneImpl(int passengerCapacity, VehicleType type,
                        double pricePerKilometer, boolean hasFreeFood) {
        super(passengerCapacity, type, pricePerKilometer);
        this.hasFreeFood = hasFreeFood;
    }

    public boolean isHasFreeFood() {
        return this.hasFreeFood;
    }

    @Override
    void validateCapacity(int passengerCapacity) {
    }

    @Override
    void validatePricePerKilometer(double pricePerKilometer) {
    }

    @Override
    public boolean hasFreeFood() {
        return false;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Airplane ----%n");
        stringBuilder.append(super.toString());
        stringBuilder.append(String.format("Has free food: %s", isHasFreeFood()));

        return stringBuilder.toString().trim();
    }
}

