package com.telerikacademy.oop.agency.models.vehicles.contracts;

public interface Airplane extends Vehicle {
    
    boolean hasFreeFood();
    
}