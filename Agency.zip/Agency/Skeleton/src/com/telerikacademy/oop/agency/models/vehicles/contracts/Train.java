package com.telerikacademy.oop.agency.models.vehicles.contracts;

public interface Train extends Vehicle {
    
    int getCarts();
    
}