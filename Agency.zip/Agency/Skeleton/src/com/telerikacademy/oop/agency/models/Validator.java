package com.telerikacademy.oop.agency.models;

public class Validator {
   public static void checkCapacity(int capacity, int max, int min){
      if (capacity < min
              || max < capacity){
         throw new IllegalArgumentException(String.format(
                 ValidationMessages.CAPACITY_INVALID));
      }
   }

   public static void checkPrice( double price, double max, double min){
      if (price < min
              || max < price){
         throw new IllegalArgumentException(ValidationMessages.PRICE_INVALID);
      }
   }
}
