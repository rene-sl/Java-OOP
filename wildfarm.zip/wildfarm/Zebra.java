package wildfarm;

public class Zebra extends Mammal {
    Zebra(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

    public void makeSound(){
        System.out.printf("Zs%n");
    }

    @Override
    public void eat(Food food) {
        if(food instanceof Vegetable){
            super.eat(food);
        } else {
            System.out.printf("Zebra are not eating that type of food!%n");
        }
    }

    @Override
    public String toString() {
        return String.format("Zebra" + super.toString());
    }
}
