package wildfarm;

public class Mouse extends Mammal {

    Mouse(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

    @Override
    public void eat(Food food) {
        if(food instanceof Vegetable){
            super.eat(food);
        } else {
            System.out.println("Mouses are not eating that type of food!");
        }

    }

    public void makeSound(){
        System.out.println("SQUEEEAAAK!");
    }

    @Override
    public String toString() {
        return String.format("Mouse" + super.toString());
    }
}
