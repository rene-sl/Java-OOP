package wildfarm;

public class Tiger extends Feline {
    private String livingRegion;

    Tiger(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
        this.livingRegion = livingRegion;
    }

    public void makeSound(){
        System.out.printf("ROAAR!!!%n");
    }

    @Override
    public void eat(Food food) {
        if(food instanceof Meat) {
            super.eat(food);
        } else {
            System.out.printf("Tigers are not eating that type of food!%n");
        }
    }

    @Override
    public String toString() {
        return String.format("Tiger" + super.toString());
    }
}
