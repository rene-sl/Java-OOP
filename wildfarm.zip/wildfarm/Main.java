package wildfarm;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();


        while (!input.equals("End")) {
            String[] infoAnimal = input.split("\\s+");
            String type = infoAnimal[0];
            String name = infoAnimal[1];
            Double weight = Double.parseDouble(infoAnimal[2]);
            String livingArea = infoAnimal[3];
            String breed = type.equals("Cat") ? infoAnimal[4] : "";
            Animal animal = null;

            switch (type){
                case "Cat":
                    animal = new Cat (name,type,weight,livingArea,breed);
                    break;
                case "Mouse":
                    animal = new Mouse (name,type,weight,livingArea);
                    break;
                case "Tiger":
                    animal = new Tiger (name,type,weight,livingArea);
                    break;
                case "Zebra":
                    animal = new Zebra (name,type,weight,livingArea);
                    break;
            }

            String[] dataFood = scanner.nextLine().split("\\s+");
            String typeFood = dataFood[0];
            Integer quantity = Integer.parseInt(dataFood[1]);
            Food food = typeFood.equals("Vegetable") ? new Vegetable(quantity) : new Meat(quantity);
            animal.makeSound();
            animal.eat(food);
            System.out.println(animal.toString());
            input = scanner.nextLine();
        }
    }
}
