package wildfarm;

public abstract class Feline extends Mammal {

    Feline(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight,livingRegion);
    }
}
