package wildfarm;

import java.text.DecimalFormat;

public class Cat extends Feline {
    private String breed;

    Cat(String animalName, String animalType, Double animalWeight, String livingRegion, String breed) {
        super(animalName, animalType, animalWeight, livingRegion );
        this.breed = breed;
    }

    public void makeSound(){
        System.out.printf("Meowwww%n");
    }

    @Override
    public void eat(Food food) {
        super.eat(food);
    }

    @Override
    public String toString() {
        DecimalFormat decimalFormat = new DecimalFormat("#.#");
        String result = String.format("Cat[%s, %s, %s, %s, %d]%n",
                super.getAnimalName(),this.breed, decimalFormat.format(super.getAnimalWeight()),
                super.getLivingRegion(), super.getFoodEaten());
        return result.trim();
    }
}
