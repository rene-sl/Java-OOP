package wildfarm;

import java.text.DecimalFormat;

abstract class Mammal extends Animal{
    private String livingRegion;

    Mammal(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight);
        this.livingRegion = livingRegion;
    }
    @Override
    public String toString() {
        DecimalFormat decimalFormat = new DecimalFormat("#.#");
        String result = String.format("[%s, %s, %s, %d]%n",
                super.getAnimalName(), decimalFormat.format(super.getAnimalWeight()),
                this.livingRegion, super.getFoodEaten());
        return result.trim();
    }

    public String getLivingRegion() {
        return livingRegion;
    }
}
