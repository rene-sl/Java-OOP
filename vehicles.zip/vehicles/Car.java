package vehicles;

public class Car extends Vehicle {
    private static final double EXTRA_CONSUMPTION = 0.9;
    private static final String NAME = "Car";
    public Car(double fuelQuantity, double litersPerKm) {
        super(fuelQuantity, litersPerKm + EXTRA_CONSUMPTION);
    }

    @Override
    public void drive(double distance){
        System.out.print("Car ");
       super.drive(distance);
    }

    @Override
    public String toString(){
        return NAME + super.toString().trim();
    }
}
