package vehicles;

public class Truck extends Vehicle {
    private static final double EXTRA_CONSUMPTION = 1.6;
    private static final String NAME = "Truck";

    public Truck(double fuelQuantity, double litersPerKm) {
        super(fuelQuantity, litersPerKm+EXTRA_CONSUMPTION);
    }

    @Override
    public boolean ableToDrive(double directionPerKm) {
        return super.ableToDrive(directionPerKm);
    }

    @Override
    public boolean needToRefuel(double directionKM) {
        return super.needToRefuel(directionKM);
    }

    @Override
    public double refuel(double newFuel) {
        return super.refuel(newFuel*0.95);
    }

    @Override
    public void drive(double distance){
        System.out.print("Truck ");
       super.drive(distance);
    }

    @Override
    public String toString(){
        return NAME + super.toString().trim();
    }
}
