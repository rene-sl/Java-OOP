package vehicles;

public interface Drivable {
    public boolean ableToDrive(double directionKm);
    public void drive(double directionKm);
    public boolean needToRefuel(double directionKm);
    public double refuel(double litters);
}
