package vehicles;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Vehicle> vehicleList = new ArrayList<>();

        for (int i = 0; i < 2 ; i++) {
            String[] dataVehicle = scanner.nextLine().split("\\s+");
            String typeVehicle = dataVehicle[0];
            double fuelQuantity = Double.parseDouble(dataVehicle[1]);
            double consumptionPerKm = Double.parseDouble(dataVehicle[2]);
                if(typeVehicle.equals("Car")){
                    Vehicle vehicle = new Car(fuelQuantity,consumptionPerKm);
                    vehicleList.add(vehicle);
                } else if(typeVehicle.equals("Truck")){
                    Vehicle vehicle = new Truck (fuelQuantity,consumptionPerKm);
                    vehicleList.add(vehicle);
                }
        }
        int numberVehicles = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < numberVehicles; i++) {
            String [] actionsInfo = scanner.nextLine().split("\\s+");
            String action = actionsInfo[0];
            String type = actionsInfo[1];
            if(action.equals("Drive")){
                double distance= Double.parseDouble(actionsInfo[2]);
                if(type.equals("Car")){
                    vehicleList.get(0).drive(distance);
                } else if (type.equals("Truck")){
                    vehicleList.get(1).drive(distance);
                }
            } else if (action.equals("Refuel")){
                double litters = Double.parseDouble(actionsInfo[2]);
                if(type.equals("Car")){
                    vehicleList.get(0).refuel(litters);
                }else if (type.equals("Truck")){
                    vehicleList.get(1).refuel(litters);
                }
            }
        }
        for (Vehicle vehicle : vehicleList) {
            System.out.println(vehicle.toString());
        }

    }
}
