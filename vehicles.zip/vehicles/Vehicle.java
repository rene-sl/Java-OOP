package vehicles;

import java.text.DecimalFormat;

public abstract class  Vehicle implements Drivable {
    private static final DecimalFormat formatter = new DecimalFormat("#.##");
    private double fuelQuantity;
    private double litersPerKm;

    public Vehicle(double fuelQuantity, double litersPerKm) {
        this.fuelQuantity = fuelQuantity;
        this.litersPerKm = litersPerKm;
    }

    @Override
    public boolean ableToDrive(double directionPerKm) {
        if(this.fuelQuantity/this.litersPerKm>=directionPerKm){
            return true;
        }
        return false;
    }

    @Override
    public void drive(double directionKm) {
        if(ableToDrive(directionKm)){
            this.fuelQuantity-=directionKm*this.litersPerKm;
            System.out.println(
                    String.format("travelled %s km",
                            formatter.format(directionKm)));
        } else {
            System.out.println("needs refueling");
        }
    }

    @Override
    public boolean needToRefuel(double directionKM) {
        if (this.fuelQuantity<=0 || !ableToDrive(directionKM)){
            return true;
        }
        return false;
    }

    @Override
    public double refuel(double newFuel) {
        return this.fuelQuantity+=newFuel;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    @Override
    public String toString(){
        return String.format(": %.2f%n",this.fuelQuantity);
    }

}

