package shoppingspree;

import java.util.ArrayList;
import java.util.List;

public class Person {
    private String name;
    private double money;
    private List<Product>products;

    public Person(String name, double money) {
        this.setName(name);
        this.setMoney(money);
        this.products=new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        Validation.validationName(name);
        this.name = name;
    }

    private void setMoney(double money) {
        Validation.validationCost(money);
        this.money = money;
    }

    public void buyProduct(Product product){
        if(product.getCost()<=this.money){
            setMoney(this.money-product.getCost());
            this.products.add(product);
        } else {
           throw new IllegalStateException
                   (String.format("%s can't afford %s%n",
                   this.getName(),product.getName()));
        }
    }

}
