package shoppingspree;

public class Validation {
    private Validation() {
    }

    public static void validationCost(double cost) {
        if (cost < 0) {
            throw new IllegalArgumentException("Money cannot be negative");
        }
    }

    public static void validationName(String name){
        if(name==null || name.trim().isEmpty()){
            throw new IllegalArgumentException ("Name cannot be empty");
        }
    }

}
