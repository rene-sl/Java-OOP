package multipleimplementation;

public interface Identifiable {
    public String getId();

}
