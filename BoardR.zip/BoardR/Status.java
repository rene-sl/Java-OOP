package BoardR;

 enum Status {
     OPEN, TODO, InPROGRESS, DONE, VERIFIED;


     @Override
     public String toString() {
         switch (this) {
             case OPEN:
                 return "Open";
             case TODO:
                 return "To Do";
             case InPROGRESS:
                 return "In Progress";
             case DONE:
                 return "Done";
             case VERIFIED:
                 return "Verified";
             default:
                 return "None";
         }
     }
 }
