package BoardR;

import java.util.ArrayList;
import java.util.List;

class Board {
     static  List<BoardItem> items = new ArrayList<>();

     private  Board(){
     }

     public  static void addItem(BoardItem item){
          if (items.contains(item)) {
               throw new IllegalArgumentException("Item already in the list");
          } else {
               items.add(item);
          }
     }

     static  int totalItems(){ return items.size();}


     public static void displayHistory(Logger logger) {
          for (BoardItem item : items) {
               logger.log(item.getHistory(logger));
          }
     }


}
