package BoardR;

import java.time.LocalDate;

public class Issue extends BoardItem {
 private String description;

    Issue(String title, String description, LocalDate dueDate) {
        super(title, dueDate, Status.OPEN);
        setDescription(description);
    }


    private void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    void validateDescription(String description){
        if( description == null){
            description = "No description";
        }
    }

    public String getDescription() {
        return description;
    }

    @Override
    void setStatus(Status status) {
            logCreated(String.format
                    ("%s status set to %s", getClass().getSimpleName(), status));
            this.status = status;
    }

    @Override
    void revertStatus() {
        if(getStatus().equals(Status.VERIFIED)){
            setStatus(Status.OPEN);
        } else {
            logCreated("Issue status already Open");
        }
    }

    @Override
    void advanceStatus() {
        if(getStatus().equals(Status.OPEN)){
            setStatus(Status.VERIFIED);
        } else {
            logCreated("Issue status already Verified");
        }
    }

    @Override
    public String viewInfo() {
        String baseInfo = super.viewInfo();
        return String.format("Issue: %s, Description: %s", baseInfo,this.getDescription());
    }
}
