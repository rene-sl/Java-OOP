package BoardR;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class EventLog {

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern
            ("dd-MMMM-yyyy HH:mm:ss");
    private final String description;
    private final LocalDateTime timestamp;



    EventLog(String description){
        if(description == null){
            throw new NullPointerException("Description should not be null");
        } else {
            this.description = description;
        }
        timestamp = LocalDateTime.now();
    }

    public String getDescription() {
        return this.description;
    }

    public LocalDateTime  getTimestamp() {
        return this.timestamp;
    }

    String  viewInfo(){
        return String.format("[%s] %s",timestamp.format(formatter), description);

    }

}
