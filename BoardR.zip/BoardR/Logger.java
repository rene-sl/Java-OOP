package BoardR;

public interface Logger {
    void log(String value);
}
