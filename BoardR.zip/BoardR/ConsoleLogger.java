package BoardR;

public class ConsoleLogger implements Logger {
    @Override
    public void log(String value) {
        System.out.printf("%s%n",value);
    }
}
