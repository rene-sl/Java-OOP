package BoardR;

import java.time.LocalDate;

public class Task extends BoardItem {
    private String assignee;

    Task(String title, String assignee,LocalDate dueDate) {
        super(title, dueDate,Status.TODO);
        validateAssignee(assignee);
        this.assignee = assignee;
}


    public String getAssignee() {
        return assignee;
    }

    void setAssignee(String assignee) {
        validateAssignee(assignee);
        logCreated(String.format("Assignee changed from %s to %s", getAssignee(), assignee));
        this.assignee = assignee;

    }

    private void validateAssignee(String assignee){
        if(assignee == null){
            throw  new IllegalArgumentException("Assignee can not be null");
        } else if (assignee.length() < 5 || 30 < assignee.length()){
            throw  new IllegalArgumentException("Assignee length must be between 5 and 30 symbols");
        }
    }


    @Override
    void setStatus(Status status) {
        logCreated(String.format
                ("Task status changed from %s to %s", getStatus(), status));
        this.status = status;
    }

    @Override
    void revertStatus() {
        Status nextStatus = Status.values()[getStatus().ordinal() - 1];
        if(Status.values()[getStatus().ordinal()].equals(Status.OPEN)){
            logCreated(String.format
                    ("Can't revert, already at %s", getStatus()));
        } else {
            setStatus(nextStatus);
        }
    }

    @Override
    void advanceStatus() {
        Status nextStatus = Status.values()[getStatus().ordinal() + 1];
        if ( nextStatus != Status.VERIFIED){
            setStatus(nextStatus);
        } else {
            logCreated(String.format
                    ("Can't advance, already at %s", getStatus()));
        }
    }

    @Override
    public String viewInfo() {
        String baseInfo = super.viewInfo();
        return String.format("Task: %s, Assignee: %s", baseInfo, this.getAssignee());
    }

}
