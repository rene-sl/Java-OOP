package BoardR;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

abstract class BoardItem {
    public final Status initialStatus  = Status.OPEN;
    public final Status finalStatus = Status.VERIFIED;

    private String title;
    private LocalDate dueDate;
     Status status;
    private List<EventLog> logs = new ArrayList<>();



    public BoardItem(String title, LocalDate dueDate) {
        this(title,dueDate,Status.OPEN);
    }

    public BoardItem(String title, LocalDate dueDate, Status status) {
        validateTitle(title);
        validateDueDate(dueDate);

        this.title = title;
        this.dueDate = dueDate;
        this.status = status;
        logCreated(String.format
                ("Item created: %s", viewInfo()));
    }


    private void validateTitle(String title) {
        if (title == null) {
            throw new NullPointerException("Title can`t be null");
        } else if (5 > title.length() || title.length() > 30) {
                throw new IllegalArgumentException
                        ("Please provide a title with length between 5 and 30 chars");
            }
        }

    private void validateDueDate(LocalDate dueDate){
        if (dueDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Due date is invalid.");
        }
    }

     void  logCreated(String event){
        logs.add(new EventLog(event));
    }


    void setTitle(String title) {
       validateTitle(title);
       logCreated(String.format
               ("Title changed to %s to %s", getTitle(), title));
       this.title = title;
    }

    public List<EventLog> getLogs() {
        return new ArrayList<>(logs);
    }

    void setDueDate(LocalDate dueDate) {
       validateDueDate(dueDate);
       logCreated(String.format
               ("DueDate changed from %s to %s",getDueDate(), dueDate));
       this.dueDate = dueDate;
    }

     abstract void setStatus(Status status);

    abstract void revertStatus();

    abstract void advanceStatus();


    String getTitle() {
        return this.title;
    }

    LocalDate getDueDate() {
        return this.dueDate;
    }

    Status getStatus() {
        return this.status;
    }

    String viewInfo() {
        return String.format("'%s', [%s | %s]", getTitle(), getStatus(), getDueDate());
    }

    public String getHistory(Logger logger) {
        StringBuilder string = new StringBuilder();
        for (EventLog log : logs) {
            string.append(log.viewInfo());
            string.append(String.format("%n"));
        }
       return string.toString().trim();
    }


}
