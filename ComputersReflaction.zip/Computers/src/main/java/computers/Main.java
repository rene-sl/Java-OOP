package computers;

import javafx.scene.effect.Reflection;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Class reflectionClass = Computer.class;
        Method[] allMethods = reflectionClass.getDeclaredMethods();
        List<Method> setters = new ArrayList<>();
        List<Method> getters = new ArrayList<>();


        for (Method method : allMethods) {
            if(isSetter(method)){
                setters.add(method);
            } else if (isGetter(method)){
                getters.add(method);
            }
        }

        setters.sort(Comparator.comparing(Method::getName));
        getters.sort(Comparator.comparing(Method::getName));

        for (Method setter : setters) {
            System.out.printf("%s will return class %s%n", setter.getName(),
                    setter.getParameterTypes()[0]);
        }

        for (Method getter : getters) {
            System.out.printf("%s and will set field of class %s%n", getter.getName(),
                    getter.getReturnType());
        }


    }

    private static boolean isGetter(Method method) {
        return method.getName().startsWith("get") &&
                method.getParameterCount() == 0 &&
                method.getGenericReturnType() != void.class;
    }

    private static boolean isSetter(Method method) {
        return method.getName().startsWith("set") &&
                method.getParameterCount() == 1 &&
                method.getGenericReturnType() == void.class;
    }
}
