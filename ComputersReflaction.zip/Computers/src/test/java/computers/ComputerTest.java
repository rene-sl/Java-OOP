package computers;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class ComputerTest {

   @Test
    public void getNameCorrectly(){
       Computer computer = new Computer("r");
       Assert.assertEquals("r", computer.getName());
   }
   @Test (expected = IllegalArgumentException.class)
    public void setNameExpectedErr(){
       Computer computer = new Computer("");
   }
   @Test
    public void addPartCorrectly(){
       Computer computer = new Computer("r");
       Part part = new Part("dyno", 4);
       Part part1 = new Part("d", 5);
       computer.addPart(part);
       computer.addPart(part1);
       Assert.assertEquals(2, computer.getParts().size());
   }

    @Test (expected = IllegalArgumentException.class)
    public void addPartException() {
        Computer computer = new Computer("r");
        Part part = null;
        computer.addPart(part);
    }
    @Test
    public void removePartCorrectly(){
        Computer computer = new Computer("r");
        Part part = new Part("dyno", 4);
        computer.addPart(part);
        computer.removePart(part);
        Assert.assertEquals(0, computer.getParts().size());
    }
    @Test
    public void getPartByNameCorrectly(){
        Computer computer = new Computer("r");
        Part part = new Part("dyno", 4);
        computer.addPart(part);
        Assert.assertEquals(part,computer.getPart("dyno"));
    }
    @Test
    public void getTotalPriceCorrectly(){
        Computer computer = new Computer("r");
        Part part = new Part("dyno", 4);
        computer.addPart(part);
        Part part1 = new Part("re", 2);
        computer.addPart(part1);
        double expected = 6;
        Assert.assertTrue(expected==computer.getTotalPrice());
    }

}