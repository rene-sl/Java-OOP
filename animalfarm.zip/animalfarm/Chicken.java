package animalfarm;

public class Chicken {
    private String name;
    private int age;

    public Chicken(String name, int age) {
        this.setName(name);
        this.setAge(age);
    }

    private void setName(String name) {
        validateName(name);
        this.name = name;
    }

    private void setAge(int age) {
        validateAge(age);
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    private void validateName(String name){
        if(name==null || name.trim().isEmpty()){
            throw  new IllegalArgumentException("Name cannot be empty");
        }
    }

    private void validateAge (int age){
        if(age<0 || 15<age){
          throw  new IllegalArgumentException("Age should be between 0 and 15.");
        }
    }

    public double productPerDay(){
        double product=0;
        if(this.getAge()<6){
            product=2;
        } else if(this.getAge()<12){
            product=1;
        } else {
            product=0.75;
        }
        return product;
    }

    @Override
    public String toString(){
        return String.format("Chicken %s (age %d) can produce %.2f eggs per day.",
                this.getName(), this.getAge(), this.productPerDay());
    }

    private double calculateProductPerDay(){
        return 0;
    }
}
