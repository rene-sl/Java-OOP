package telephony;

public class Validation {
    public static boolean validatePhoneNumber(String number){
        for (int i = 0; i < number.length() ; i++) {
            char letter = (char)number.charAt(i);
            if(!Character.isDigit(letter)){
                return false;
            }
        }
        return true;
    }

    public static boolean validateUrl (String url){
        for (int i = 0; i < url.length() ; i++) {
            char letter = (char)url.charAt(i);
            if(Character.isDigit(letter)){
                return false;
            }
        }
        return true;
    }
}
