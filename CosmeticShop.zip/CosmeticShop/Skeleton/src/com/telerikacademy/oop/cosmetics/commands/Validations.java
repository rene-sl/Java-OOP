package com.telerikacademy.oop.cosmetics.commands;

import java.util.Collections;
import java.util.List;

public class Validations {



    public static void checkForNull(Object object){
        if(object == null){
            throw new NullPointerException(ValidationMessages.NULL_EXCEPTION);
        }
    }
    public static void checkForNegative( double price){
        if(price < 0){
            throw new IllegalArgumentException(ValidationMessages.NEGATIVE_NUMBER_EXCEPTION);
        }
    }
    public static void checkForLength(String string, int max, int min){
        if(string.length() < min ||string.length() > max){
            throw new IllegalArgumentException
                    (ValidationMessages.LENGTH_INCORRECT);
        }
    }
    public static <E> void checkForEmptyCollection(List<E> collections){
        if(collections.size() == 0 ){
            throw new IllegalArgumentException(ValidationMessages.EMPTY_COLLECTION);
        }
    }
}
