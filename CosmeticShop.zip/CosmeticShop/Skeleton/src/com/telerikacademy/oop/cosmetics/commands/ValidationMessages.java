package com.telerikacademy.oop.cosmetics.commands;

public class ValidationMessages {
    public static String NULL_EXCEPTION = "This input can not be null.";
    public static String NEGATIVE_NUMBER_EXCEPTION = "This input can not be negative.";
    public static String LENGTH_INCORRECT = "This input must be in correct borders.";
    public static String INCORRECT_TYPE = "This type is incorrect.";
    public static String EMPTY_COLLECTION = "This collection is empty.";
}
