package hero;

public class Wizard extends Hero {
    public Wizard(String userName, int level) {
        super(userName, level);
    }
}
