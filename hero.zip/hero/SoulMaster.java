package hero;

public class SoulMaster extends DarkWizard {
    public SoulMaster(String userName, int level) {
        super(userName, level);
    }
}
