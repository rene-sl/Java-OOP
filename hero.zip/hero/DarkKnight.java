package hero;

public class DarkKnight extends Knight {
    public DarkKnight(String userName, int level) {
        super(userName, level);
    }
}
