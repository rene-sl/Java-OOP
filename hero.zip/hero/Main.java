package hero;

public class Main {
}
