package hero;

public class DarkWizard extends Wizard {
    public DarkWizard(String userName, int level) {
        super(userName, level);
    }
}
