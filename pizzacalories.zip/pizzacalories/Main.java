package pizzacalories;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] pizzaData = scanner.nextLine().split("\\s+");
        String pizzaName = pizzaData[1];
        int numberOfToppings = Integer.parseInt(pizzaData[2]);
        Pizza pizza = new Pizza(pizzaName, numberOfToppings);

        String[] doughData = scanner.nextLine().split("\\s+");
        String flourType = doughData[1];
        String bakingTechnique = doughData[2];
        double weightInGrams = Double.parseDouble(doughData[3]);
        Dough dough = new Dough(flourType, bakingTechnique, weightInGrams);

        String input = scanner.nextLine();
        while (!input.equals("END")) {
            String toppingType = doughData[1];
            double weightTopping = Double.parseDouble(doughData[2]);

            Topping topping = new Topping(toppingType, weightInGrams);
            pizza.addTopping(topping);
        }
        input = scanner.nextLine();
    }
}
