package pizzacalories;

public class Validation {
    public Validation() {
    }

    public static void validTypeDough(String str){
        if(str==null || str.trim().isEmpty()){
            throw new IllegalArgumentException("Invalid type of dough.%n" );
        }
    }

    public static void validDough(double dough){
        if(dough<=0 || 200<dough){
            throw  new IllegalArgumentException("Dough weight should be in the range [1..200].%n");
        }
    }

    public static void validTopping(String topping){
        if(!(topping.equals("Meat")) || !(topping.equals("Veggies"))
                || !(topping.equals("Cheese")) || (!topping.equals("Sauce"))){
            throw new IllegalArgumentException("Cannot place "+ topping + "on top of your pizza.%n");
        }
    }

    public static void validToppingWeight(double weight, Topping topping){
        if(weight<1 || 50<weight){
            throw new IllegalArgumentException(topping.getToppingType()+
                    " weight should be in the range [1..50].%n");
        }
    }

    public static void validPizzaName(String name){
        if(name==null || name.trim().isEmpty()){
            throw new IllegalArgumentException("Pizza name should be between 1 and 15 symbols.%n");
        }
    }

    public static void validToppingNumbers(int num){
        if(num<0 || 10<num){
            throw new IllegalArgumentException("Number of toppings should be in range [0..10].%n");
        }
    }
}

