package pizzacalories;

public class Dough {
    private String flourType;
    private String bakingTechnique;
    private double weight;

    public Dough(String flourType, String bakingTechnique, double weight) {
        this.setFlourType(flourType);
        this.setBakingTechnique(bakingTechnique);
        this.setWeight(weight);
    }

    private void setFlourType(String flourType) {
        Validation.validTypeDough(flourType);
        this.flourType = flourType;
    }

    private void setBakingTechnique(String bakingTechnique) {
        Validation.validTypeDough(bakingTechnique);
        this.bakingTechnique = bakingTechnique;
    }

    private void setWeight(double weight) {
        Validation.validDough(weight);
        this.weight = weight;
    }

    public double calculateCalories(){
        double modifierType = modifierIndex(flourType);
        double modifierTechnique=modifierIndex(bakingTechnique);

        return (2*this.weight)*modifierType*modifierTechnique;
    }

    private double modifierIndex(String type){
        double modifierIndex=0;
        if(type.equals("White")){
            modifierIndex=1.5;
        } else if (type.equals("Wholegrain") ){
            modifierIndex=1.0;
        } else if (type.equals("Crispy")){
            modifierIndex=0.9;
        }else if (type.equals("Chewy")){
            modifierIndex=1.1;
        } else if (type.equals("Homemade")){
            modifierIndex=1.0;
        }
        return modifierIndex;
    }
}
