package pizzacalories;

public class Topping {
    private String toppingType;
    private double weight;

    public Topping(String toppingType, double weight) {
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    private void setToppingType(String toppingType) {
        Validation.validTopping(toppingType);
        this.toppingType = toppingType;
    }

    private void setWeight(double weight) {
        this.weight = weight;
    }

    public double calculateCalories(String toppingType){
        double modifier =0;
        if(toppingType.equals("Meat")){
            modifier=1.2;
        } else if (toppingType.equals("Veggies")){
            modifier=0.8;
        } else if (toppingType.equals("Cheese")){
            modifier=1.1;
        }else if (toppingType.equals("Sauce")){
            modifier=0.9;
        }
        return (2*this.weight)*modifier;
    }

    public String getToppingType() {
        return toppingType;
    }
}
