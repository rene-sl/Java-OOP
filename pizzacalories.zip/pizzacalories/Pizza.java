package pizzacalories;

import java.util.ArrayList;
import java.util.List;

public class Pizza {
    private String name;
    private  Dough dough;
    private List<Topping> topping;

    public Pizza(String name, int numberOfToppings) {
        this.setName(name);
        this.setToppings(numberOfToppings);
    }

    private void setName(String name) {
        Validation.validPizzaName(name);
        this.name = name;
    }

    private void setToppings(int numberTopping){
        Validation.validToppingNumbers(numberTopping);
        this.topping = new ArrayList<>(numberTopping);
    }

    public void setDough(Dough dough){
        this.dough=dough;
    }

    public String getName() {
        return name;
    }

    public void addTopping(Topping topping){
    }

    public double getOverallCalories(){
        return 0;
    }
}
