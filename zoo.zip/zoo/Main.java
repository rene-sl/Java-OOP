package zoo;

public class Main {
    public Main() {
    }
}
