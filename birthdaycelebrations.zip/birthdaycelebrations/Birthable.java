package birthdaycelebrations;

public interface Birthable {
    public String getBirthDate();
}
