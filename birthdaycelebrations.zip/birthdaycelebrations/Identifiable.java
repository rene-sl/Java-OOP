package birthdaycelebrations;

public interface Identifiable {
    public String getId();

}
